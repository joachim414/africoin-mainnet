const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying Africoin from:", deployer.address);

  const balance = await deployer.getBalance();
  console.log("Account balance:", hre.ethers.utils.formatEther(balance), "MATIC");

  const Africoin = await hre.ethers.getContractFactory("Africoin");
  const africoin = await Africoin.deploy();
  await africoin.deployed();

  console.log("✅ Africoin deployed to:", africoin.address);
}

main().catch((error) => {
  console.error("❌ Deployment failed:", error);
  process.exitCode = 1;
});
