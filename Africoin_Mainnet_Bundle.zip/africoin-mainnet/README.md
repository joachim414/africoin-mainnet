# Africoin Mainnet Deployment

This repository contains the smart contract deployment script, ABI, and documentation for launching Africoin ($AFC) on the Polygon Mainnet.

## 🚀 What’s Included

- ✅ `deploy-mainnet.js`: Hardhat script to deploy the ERC-20 Africoin token
- ✅ `Africoin.abi.json`: ABI for wallet integration or dApp use
- ✅ `README.md`: Deployment and usage instructions

## 📝 Deployment Instructions

1. Create a `.env` file with:

```
PRIVATE_KEY=your_wallet_private_key
POLYGON_API=https://polygon-mainnet.infura.io/v3/your_project_id
```

2. Install dependencies:

```
npm install
```

3. Run deployment:

```
npx hardhat run scripts/deploy-mainnet.js --network polygon
```

## 📦 Wallet & APK

The AfricoinX wallet APK and source code are stored separately. Contact the core team to access Android/iOS builds.

## 📬 Contact & License

Contact: team@africoin.org  
License: MIT
